require 'spec_helper'

describe Show do
  pending "add some examples to (or delete) #{__FILE__}"
end
