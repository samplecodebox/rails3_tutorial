require 'spec_helper'

describe SeasonsController do

end
