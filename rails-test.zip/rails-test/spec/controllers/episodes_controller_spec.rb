require 'spec_helper'

describe EpisodesController do

end
