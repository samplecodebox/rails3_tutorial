Factory.define :season do |season|
  season.number '1'
  season.association :show
end
