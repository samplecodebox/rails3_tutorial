
Factory.define :show do |show|
  show.name 'Tom&Jerry'
  show.description 'Hello Tom&Jerry'
end