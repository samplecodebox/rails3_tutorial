# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SynctvTest::Application.config.secret_token = '5aedb111b057c405a4ebc1bd88edbb7fc7015b3f7101e202c71f9a92b5ce01a1858c215f3f9f9c41d813a56002163e83fa2f525c190fb50b7ff251f0a4b16a21'
